#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include"conio2.h"
#include"car.h"

void addAdmin()
{
    FILE*fp=fopen("admin.bin","rb");
    if(fp==NULL)
    {
        fp=fopen("admin.bin","wb");
        User u[2]={{"admin","test","tushar"},{"super","demo","morey"}};
        fwrite(u,sizeof(u),1,fp);
    }
    fclose(fp);
}
User*getInput()
{
    int i;
    clrscr();
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,10);
    textcolor(LIGHTBLUE);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,20);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,5);
    textcolor(LIGHTCYAN);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(33,6);
    textcolor(YELLOW);
    printf("* Login Panel *");
    gotoxy(65,11);
    textcolor(WHITE);
    printf("Press 0 to exit");
    gotoxy(32,14);
    textcolor(LIGHTMAGENTA);
    printf("Enter ID:");
    static User u;
    textcolor(WHITE);
    fflush(stdin);
    fgets(u.userid,20,stdin);
    char *pos;
    pos=strchr(u.userid,'\n');
    if(pos!=NULL)
        *pos='\0';
    if(strcmp(u.userid,"0")==0)
    {
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("Login Cancelled!");
        getch();
        return NULL;
    }
    gotoxy(32,15);
    textcolor(LIGHTMAGENTA);
    printf("Enter password:");
    fflush(stdin);
    i=0;
    textcolor(WHITE);
    for(;;)
    {
        u.pwd[i]=getch();
        if(u.pwd[i]==13)
            break;
        printf("*");
        i++;
    }
    u.pwd[i]='\0';
     if(strcmp(u.pwd,"0")==0)
    {
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("Login Cancelled!");
        getch();
        return NULL;
    }
    return &u;
}
int checkUserExist(User u,char*usertype)
{
    if(strlen(u.userid)==0 || strlen(u.pwd)==0)
    {
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("Both fields are mandatory. Try again!");
        getch();
        gotoxy(32,21);
        printf("\t\t\t\t\t\t\t");
        return 0;
    }
    FILE*fp;
    if(strcmp(usertype,"admin")==0)
    {
        fp=fopen("admin.bin","rb");

    }
    else
    {
        fp=fopen("emp.bin","rb");
    }
    if(fp==NULL)
    {
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("Cannot open File!");
        getch();
        gotoxy(32,21);
        printf("\t\t\t\t\t\t\t");
        return -1;
    }
    int found=0;
    User user;
    while(fread(&user,sizeof(user),1,fp)==1)
    {
        if(strcmp(u.userid,user.userid)==0 && strcmp(u.pwd,user.pwd)==0)
        {
            found=1;
            break;
        }
    }
        if(found==0)
        {
            gotoxy(32,22);
            textcolor(LIGHTRED);
            printf("Invalid User id/password. Try again!");
            getch();
            gotoxy(32,21);
            printf("\t\t\t\t\t\t\t");
            return 0;
        }
        else
        {
            gotoxy(32,22);
            textcolor(GREEN);
            printf("Login Successfully!");
            getch();
            gotoxy(32,21);
            printf("\t\t\t\t\t\t\t");
            return 1;
        }
    fclose(fp);
    return found;
}
int adminMenu()
{
    int i,choice;
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(GREEN);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(33,6);
    textcolor(LIGHTCYAN);
    printf("* ADMIN MENU *");
    gotoxy(1,9);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,20);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,11);
    textcolor(YELLOW);
    printf("1. Add Employee");
    gotoxy(32,12);
    printf("2. Add Car Details");
    gotoxy(32,13);
    printf("3. Show Employee");
    gotoxy(32,14);
    printf("4. Show Car Details");
    gotoxy(32,15);
    printf("5. Delete Employee");
    gotoxy(32,16);
    printf("6. Delete Car Details");
    gotoxy(32,17);
    printf("7. Exit");
    gotoxy(32,19);
    textcolor(WHITE);
    printf("Enter your choice:");
    scanf("%d",&choice);
    return choice;
}
void addEmployee()
{
    char *pos;
    char temp[20];
    char choice;
    User u;
    FILE*fp=fopen("emp.bin","ab+");
    fseek(fp,0,SEEK_END);
    long total_rec=ftell(fp)/sizeof(User);
    if(total_rec!=0)
    {
        fseek(fp,-60,SEEK_END);
        fread(temp,sizeof(temp),1,fp);
        pos=strchr(temp,'-');
        total_rec=atoi(pos+1);
    }
    total_rec++;
    sprintf(u.userid,"EMP-%lu",total_rec);
    fseek(fp,0,SEEK_END);
    do
    {
        clrscr();
    int i;
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(28,6);
    textcolor(LIGHTCYAN);
    printf("* ADD EMPLOYEE DETAILS *");
     gotoxy(1,9);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,23);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,11);
    textcolor(YELLOW);
    printf("Enter Employee Name:");
    fflush(stdin);
    textcolor(WHITE);
    fgets(u.name,20,stdin);
    pos=strchr(u.name,'\n');
    if(pos!=NULL)
        *pos='\0';
    textcolor(YELLOW);
    printf("Enter Employee password:");
    fflush(stdin);
    textcolor(WHITE);
    fgets(u.pwd,20,stdin);
    pos=strchr(u.pwd,'\n');
    if(pos!=NULL)
        *pos='\0';
    fwrite(&u,sizeof(u),1,fp);
    gotoxy(32,16);
    textcolor(LIGHTGREEN);
    printf("EMPLOYEE ADDED SUCCESSFULLY!");
    printf("\nEMPLOYEE ID IS %s",u.userid);
    gotoxy(1,20);
    textcolor(LIGHTCYAN);
    printf("DO YOU WANT TO ADD MORE EMPLOYEE'S(Y/N)? ");
    textcolor(WHITE);
    fflush(stdin);
    scanf("%c",&choice);
    if(choice=='N')
        break;
    total_rec++;
    sprintf(u.userid,"EMP-%lu",total_rec);
    }while(1);
    fclose(fp);
}
void addCarDetails()
{
    int i,temp;
    char *pos;
    char choice;
    Car c;
    FILE*fp=fopen("car.bin","ab+");
    fseek(fp,0,SEEK_END);
    long count=ftell(fp)/sizeof(Car);
    if(count!=0)
    {
        fseek(fp,-(unsigned long int)sizeof(c),SEEK_END);
        fread(&temp,sizeof(temp),1,fp);
        count=temp;
        fseek(fp,0,SEEK_END);

    }
    do
    {
        clrscr();
        count++;
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(30,6);
    textcolor(LIGHTCYAN);
    printf("* ADD CAR DETAILS *");
     gotoxy(1,9);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,23);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,11);
    textcolor(YELLOW);
    printf("Enter Car Model:");
    fflush(stdin);
    textcolor(WHITE);
    fgets(c.car_name,50,stdin);
    pos=strchr(c.car_name,'\n');
    if(pos!=NULL)
        *pos='\0';
    textcolor(YELLOW);
    printf("Enter Car Capacity:");
    fflush(stdin);
    textcolor(WHITE);
    scanf("%d",&c.capacity);
    textcolor(YELLOW);
    printf("Enter Car Count:");
    textcolor(WHITE);
    scanf("%d",&c.car_count);
    c.car_id=c.car_count;
    textcolor(YELLOW);
    printf("Enter Car Price/Day:");
    textcolor(WHITE);
    scanf("%d",&c.price);
    c.car_id=count;
    fwrite(&c,sizeof(c),1,fp);
    gotoxy(32,16);
    textcolor(LIGHTGREEN);
    printf("CAR ADDED SUCCESSFULLY!");
    printf("\nCAR ID IS %ld",count);
    gotoxy(1,20);
    textcolor(LIGHTCYAN);
    printf("DO YOU WANT TO ADD MORE CAR'S(Y/N)? ");
    textcolor(WHITE);
    fflush(stdin);
    scanf("%c",&choice);
    if(choice=='N')
        break;
    }while(1);
    fclose(fp);
}
void viewEmployee()
{
    User u;
    int i;
    FILE*fp=fopen("emp.bin","rb");
    if(fp==NULL)
    {
        printf("No Employee Present!");
        getch();
        return;
    }
    gotoxy(32,3);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,6);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(30,7);
    textcolor(LIGHTMAGENTA);
    printf("* EMPLOYEE DETAILS *");
    gotoxy(1,8);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
     gotoxy(1,9);
    textcolor(LIGHTCYAN);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,25);
    for(i=0;i<80;i++)
    printf("%c",247);
    textcolor(LIGHTCYAN);
     gotoxy(1,12);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,11);
    textcolor(YELLOW);
    printf("EMPLOYEE ID\t\t\t    NAME\t\t\t     PASSWORD");
    textcolor(LIGHTGREEN);
    int row=13;
    while(fread(&u,sizeof(u),1,fp)==1)
    {
         gotoxy(1,row);
         printf("%s",u.userid);
         gotoxy(37,row);
         printf("%s",u.name);
         gotoxy(70,row);
         printf("%s",u.pwd);
         row++;
    }
    getch();
    fclose(fp);
}
void showCarDetails()
{
    Car c;
    int i;
    FILE*fp=fopen("car.bin","rb");
    if(fp==NULL)
    {
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("No car present!");
        getch();
        return;
    }
    gotoxy(32,3);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,6);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(33,7);
    textcolor(LIGHTMAGENTA);
    printf("* CAR DETAILS *");
    gotoxy(1,8);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
     gotoxy(1,9);
    textcolor(LIGHTCYAN);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,25);
    for(i=0;i<80;i++)
    printf("%c",247);
    textcolor(LIGHTCYAN);
     gotoxy(1,12);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,11);
    textcolor(YELLOW);
    printf("MODEL\t\tCAR ID\t\tCAPACITY\t\tCAR COUNT\tPRICE");
    textcolor(LIGHTGREEN);
    int row =13;
    while((fread(&c,sizeof(c),1,fp))==1)
    {
       gotoxy(1,row);
       printf("%s",c.car_name);
       gotoxy(17,row);
       printf("%d",c.car_id);
       gotoxy(33,row);
       printf("%d",c.capacity);
       gotoxy(57,row);
       printf("%d",c.car_count);
       gotoxy(73,row);
       printf("%d",c.price);
       row++;
    }
    getch();
    fclose(fp);
}
int deleteEmp()
{
    User u;
    char empid[15];
    int i,found=0,result;
    FILE*fp1,*fp2;
    fp1=fopen("emp.bin","rb");
    if(fp1==NULL)
    {
        printf("No Employees Added Yet!");
        return -1;
    }
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(31,6);
    textcolor(LIGHTCYAN);
    printf("* DELETE EMPLOYEE *");
    gotoxy(1,9);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,15);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,12);
    textcolor(YELLOW);
    printf("ENTER EMPLOYEE ID:");
    textcolor(WHITE);
    scanf("%s",empid);
    fp2=fopen("temp.bin","wb");
    if(fp2==NULL)
    {
        printf("Cannot Open File!");
        return -1;
    }
    while(fread(&u,sizeof(u),1,fp1)==1)
    {
       if(strcmp(u.userid,empid)!=0)
           fwrite(&u,sizeof(u),1,fp2);
        else
            found=1;
    }
    fclose(fp1);
    fclose(fp2);
    if(found==0)
        remove("temp.bin");
    else
    {
        result=remove("emp.bin");
        if(result!=0)
            return 2;
        result=rename("temp.bin","emp.bin");
        if(result!=0)
                return 2;
    }
    return found;
    getch();
}
int deleteCarModel()
{
    Car c;
    int carid;
    int i,found=0,result;
    FILE*fp1,*fp2;
    fp1=fopen("car.bin","rb");
    if(fp1==NULL)
    {
        printf("No Car's Added Yet!");
        return -1;
    }
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(LIGHTCYAN);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(31,6);
    textcolor(LIGHTMAGENTA);
    printf("* DELETE CAR MODEL *");
    gotoxy(1,9);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,15);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,12);
    textcolor(YELLOW);
    printf("ENTER CAR ID:");
    textcolor(WHITE);
    scanf("%d",&carid);
    fp2=fopen("temp.bin","wb");
    if(fp2==NULL)
    {
        printf("Cannot Open File!");
        return -1;
    }
    while(fread(&c,sizeof(c),1,fp1)==1)
    {
       if(c.car_id!=carid)
           fwrite(&c,sizeof(c),1,fp2);
        else
            found=1;
    }
    fclose(fp1);
    fclose(fp2);
    if(found==0)
        remove("temp.bin");
    else
    {
        result=remove("car.bin");
        if(result!=0)
            return 2;
        result=rename("temp.bin","car.bin");
        if(result!=0)
                return 2;
    }
    return found;
    getch();
}
int EmpMenu()
{
     int i,choice;
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,6);
    textcolor(LIGHTCYAN);
    printf("* EMPLOYEE MENU *");
    gotoxy(1,9);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,20);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,11);
    textcolor(YELLOW);
    printf("1. Rent a Car");
    gotoxy(32,12);
    printf("2. Booking Details");
    gotoxy(32,13);
    printf("3. Available Car Details");
    gotoxy(32,14);
    printf("4. Show All Car Details");
    gotoxy(32,15);
    printf("5. Return Car");
    gotoxy(32,16);
    printf("6. Exit");
    gotoxy(32,17);
    textcolor(WHITE);
    printf("Enter your choice:");
    scanf("%d",&choice);
    return choice;
}
int selectCarModel()
{
    int flag,choice;
    Car c;
    FILE*fp=fopen("car.bin","rb");
    if(fp==NULL)
    {
        printf("Cannot open file!");
        getch();
        return -1;
    }
    int row=12;
    gotoxy(32,row);
    textcolor(YELLOW);
    int carcount=0;
    while(fread(&c,sizeof(c),1,fp)==1)
    {
        if(c.car_count>0)
        {
            printf("CAR ID=%d . %s",c.car_id,c.car_name);
            gotoxy(32,++row);
            ++carcount;
        }
    }
    if(carcount==0)
    {
        fclose(fp);
        return -2;
    }
    gotoxy(32,row+2);
    textcolor(WHITE);
    printf("Enter your choice(Enter 0 to Quit):");
    while(1)
    {
        flag=0;
        scanf("%d",&choice);
        if(choice==0)
        {
            fclose(fp);
            return 0;
        }
        rewind(fp);
     while(fread(&c,sizeof(c),1,fp)==1)
      {
        if(c.car_id==choice && c.car_count>0)
        {
            flag=1;
            break;
        }
      }
      if(flag==1)
      {
          fclose(fp);
          return c.car_id;
      }
      gotoxy(32,row+6);
      textcolor(LIGHTRED);
      printf("Wrong Input.Try Again!");
      getch();
      gotoxy(32,row+6);
      printf("\t\t\t\t\t");
      gotoxy(67,row+2);
      printf("\t\t\t");
      gotoxy(67,row+2);
      textcolor(WHITE);
    }
}
int isValidDate(struct tm dt)
{
    if(dt.tm_year>=2021 && dt.tm_year<=2022)
    {
        if(dt.tm_mon>=1 && dt.tm_mon<=12)
        {
            if((dt.tm_mday>=1 && dt.tm_mday<=31) && (dt.tm_mon==1 || dt.tm_mon==3 || dt.tm_mon==5 || dt.tm_mon==7 || dt.tm_mon==8 || dt.tm_mon==10 || dt.tm_mon==12) )
            {
                return 1;
            }
            else if((dt.tm_mday>=1 && dt.tm_mday<=30) && (dt.tm_mon==4 || dt.tm_mon==6 || dt.tm_mon==9 || dt.tm_mon==11))
                return 1;
            else if(dt.tm_mday>=1 && dt.tm_mday<=28 && dt.tm_mon==2)
                return 1;
            else if(dt.tm_mday>=1 && dt.tm_mday<=29 && dt.tm_mon==2 && (dt.tm_year%400==0 || (dt.tm_year%4==0 && dt.tm_year%100!=0)))
                return 1;
        }

    }
    return 0;
}
void updateCarCount(int c_id)
{
    FILE*fp=fopen("car.bin","rb+");
    if(fp==NULL)
    {
        printf("Cannot open file!");
        getch();
        return;
    }
    Car C;
    while(fread(&C,sizeof(Car),1,fp)==1)
    {
        if(c_id==C.car_id)
        {
            int x;
            x=C.car_count;
            x--;
            fseek(fp,-8,SEEK_CUR);
            fwrite(&x,sizeof(int),1,fp);
            break;
        }
    }
    fclose(fp);
}
void BookedCarDetails()
{
    int i;
    clrscr();
    FILE*fp=fopen("Customer.bin","rb");
    if(fp==NULL)
    {
        printf("Cannot open file");
        getch();
        return;
    }
    Car_Customer_Details cc;
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(MAGENTA);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(30,6);
    textcolor(LIGHTCYAN);
    printf("* BOOKED CAR DETAILS *");
    gotoxy(1,9);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,12);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,24);
    for(i=0;i<80;i++)
    printf("%c",247);
     gotoxy(1,10);
     textcolor(LIGHTCYAN);
     printf("Model\t     CustName\t   PickUp\t  Drop\t        S_Date\t     E_Ddate");
     int row =13;
     while(fread(&cc,sizeof(Car_Customer_Details),1,fp)==1)
     {
         textcolor(YELLOW);
         gotoxy(1,row);
         printf("%s",getCarname(cc.car_id));
         gotoxy(14,row);
         printf("%s",cc.cust_name);
         gotoxy(28,row);
         printf("%s",cc.pickup);
         gotoxy(43,row);
         printf("%s",cc.drop);
         gotoxy(57,row);
         printf("%d-%d-%d",cc.sd.tm_mday,cc.sd.tm_mon,cc.sd.tm_year);
          gotoxy(70,row);
         printf("%d-%d-%d",cc.ed.tm_mday,cc.ed.tm_mon,cc.ed.tm_year);
         row++;
     }
     fclose(fp);
     getch();
}
char* getCarname(int c_id)
{
   FILE*fp=fopen("car.bin","rb");
   if(fp==NULL)
   {
       printf("Cannot open file!");
       getch();
       return NULL;
   }
   static Car c;
   while(fread(&c,sizeof(c),1,fp)==1)
   {
       if(c_id==c.car_id)
       {
           break;
       }
   }
   fclose(fp);
   return c.car_name;
}
int RentCar()
{
    Car_Customer_Details cc;
    int i,c;
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,6);
    textcolor(LIGHTCYAN);
    printf("* EMPLOYEE MENU *");
    gotoxy(1,9);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,25);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,11);
    c=selectCarModel();
    if(c==0 || c==-2)
        return c;
    clrscr();
    gotoxy(32,2);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,5);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,7);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,6);
    textcolor(LIGHTCYAN);
    printf("* EMPLOYEE MENU *");
    gotoxy(1,9);
    textcolor(LIGHTMAGENTA);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(1,24);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(32,12);
    textcolor(YELLOW);
    printf("Enter Customer Name:");
    fflush(stdin);
    textcolor(WHITE);
    fgets(cc.cust_name,30,stdin);
    char *pos;
    pos=strchr(cc.cust_name,'\n');
    if(pos!=NULL)
        *pos='\0';
    gotoxy(32,13);
    textcolor(YELLOW);
    printf("Enter Pickup Point:");
    fflush(stdin);
    textcolor(WHITE);
    fgets(cc.pickup,30,stdin);
    pos=strchr(cc.pickup,'\n');
    if(pos!=NULL)
        *pos='\0';
    gotoxy(32,14);
    textcolor(YELLOW);
    printf("Enter Drop Point:");
    fflush(stdin);
    textcolor(WHITE);
    fgets(cc.drop,30,stdin);
    pos=strchr(cc.drop,'\n');
    if(pos!=NULL)
        *pos='\0';
    gotoxy(32,15);
    textcolor(YELLOW);
    printf("Enter Start Date(DD-MM-YYYY):");
    textcolor(WHITE);
    do
    {
        scanf("%d-%d-%d",&cc.sd.tm_mday,&cc.sd.tm_mon,&cc.sd.tm_year);
        int datevalid=isValidDate(cc.sd);
        if(datevalid==1)
            break;
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("Wrong Date! Try again.");
        getch();
        gotoxy(32,22);
        printf("\t\t\t\t\t");
        gotoxy(61,15);
        printf("\t\t\t");
        gotoxy(61,15);
        textcolor(WHITE);
    }while(1);
    gotoxy(32,16);
    textcolor(YELLOW);
    printf("Enter End Date(DD-MM-YYYY):");
    textcolor(WHITE);
    do
    {
        scanf("%d-%d-%d",&cc.ed.tm_mday,&cc.ed.tm_mon,&cc.ed.tm_year);
        int datevalid=isValidDate(cc.ed);
        if(datevalid==1)
            break;
        gotoxy(32,22);
        textcolor(LIGHTRED);
        printf("Wrong Date! Try again.");
        getch();
        gotoxy(32,22);
        printf("\t\t\t\t\t");
        gotoxy(59,16);
        printf("\t\t\t");
        gotoxy(59,16);
        textcolor(WHITE);
    }while(1);
    time_t obj=time(0);
    struct tm *p=localtime(&obj);
    if(cc.sd.tm_mday!=p->tm_mday)
    {
        gotoxy(32,18);
        textcolor(LIGHTRED);
        printf("Invalid Starting date!");
        getch();
        gotoxy(32,18);
        printf("\t\t\t\t");
        gotoxy(61,15);
        printf("\t\t\t\t");
        gotoxy(61,15);
        textcolor(WHITE);
        scanf("%d-%d-%d",&cc.sd.tm_mday,&cc.sd.tm_mon,&cc.sd.tm_year);
    }
    if(((cc.ed.tm_mday)||(cc.ed.tm_mon))<=((cc.ed.tm_mday)||(cc.ed.tm_mon)))
    {
        gotoxy(32,18);
        textcolor(LIGHTRED);
        printf("Invalid Ending date!");
        getch();
        gotoxy(32,18);
        printf("\t\t\t\t");
        gotoxy(59,16);
        printf("\t\t\t\t");
        gotoxy(59,16);
        textcolor(WHITE);
        scanf("%d-%d-%d",&cc.ed.tm_mday,&cc.ed.tm_mon,&cc.ed.tm_year);
    }
    FILE*fp=fopen("Customer.bin","ab+");
    if(fp==NULL)
    {
        gotoxy(32,18);
        printf("Cannot open File!");
        getch();
        return -1;
    }
    cc.car_id=c;
    fwrite(&cc,sizeof(Car_Customer_Details),1,fp);
    gotoxy(1,18);
    textcolor(LIGHTGREEN);
    printf("Booking Done!for Car ID=%d",cc.car_id);
    printf("\nPress any key to Continue!..");
    getch();
    fclose(fp);
    updateCarCount(c);
    BookedCarDetails();
    return 1;
}
void AvailCarDetails()
{
    FILE*fp=fopen("car.bin","rb");
    if(fp==NULL)
    {
        printf("Cannot open File!");
        getch();
        return;
    }
    Car c;
    int i;
    gotoxy(32,3);
    textcolor(LIGHTGRAY);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,6);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
    gotoxy(31,7);
    textcolor(LIGHTMAGENTA);
    printf("* AVAILABLE CAR DETAILS *");
    gotoxy(1,8);
    textcolor(BLUE);
    for(i=0;i<80;i++)
    printf("*");
     gotoxy(1,9);
    textcolor(LIGHTCYAN);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,25);
    for(i=0;i<80;i++)
    printf("%c",247);
    textcolor(LIGHTCYAN);
     gotoxy(1,12);
    for(i=0;i<80;i++)
    printf("%c",247);
    gotoxy(1,11);
    printf("Car ID\t\t Model\t\t Capacity\t     Count\t   Price/Day");
    int row =13;
    textcolor(YELLOW);
    while(fread(&c,sizeof(c),1,fp)==1)
    {
        if(c.car_count>0)
        {
          gotoxy(1,row);
          printf("%d",c.car_id);
          gotoxy(18,row);
          printf("%s",c.car_name);
          gotoxy(36,row);
          printf("%d",c.capacity);
          gotoxy(54,row);
          printf("%d",c.car_count);
          gotoxy(68,row);
          printf("%d",c.price);
          row=row+1;
        }
    }
    getch();
    fclose(fp);
}

int returnCar()
{
    FILE *fp1=fopen("customer.bin","rb");
    int c_id;
    int i,result;
    textcolor(LIGHTGRAY);
    gotoxy(32,2);
    printf("CAR RENTAL SYSTEM");
    gotoxy(1,4);
    textcolor(YELLOW);
    for(i=1;i<=80;i++)
    {
        printf("%c",247);
    }
    gotoxy(33,5);
    textcolor(LIGHTMAGENTA);
    printf("* Return Car *");
    gotoxy(1,6);
    textcolor(YELLOW);
    for(i=1;i<=80;i++)
    {
        printf("%c",247);
    }
    gotoxy(1,9);
    textcolor(LIGHTBLUE);
    for(i=1;i<=80;i++)
    {
        printf("%c",247);
    }
    gotoxy(1,24);
    for(i=1;i<=80;i++)
    {
        printf("%c",247);
    }
    if(fp1==NULL)
    {
        textcolor(LIGHTRED);
        gotoxy(32,10);
        printf("No Car booked yet!");
        getch();
        return -1;
    }
    FILE *fp2=fopen("temp.bin","wb");
    if(fp2==NULL)
    {
        textcolor(LIGHTRED);
        gotoxy(32,10);
        printf("Sorry ! cannot create temp file");
        getch();
        return -1;
    }
    gotoxy(32,11);
    textcolor(LIGHTCYAN);
    printf("Enter Car id to return Car:");
    textcolor(WHITE);
    scanf("%d",&c_id);
    Car_Customer_Details CC;
    int found=0;
    while(fread(&CC,sizeof(CC),1,fp1)==1)
    {
        if(found==0||found==1)
        {
            if(found==1)
            {
                 fwrite(&CC,sizeof(CC),1,fp2);
            }
            else
            {
                if(CC.car_id!=c_id)
                  fwrite(&CC,sizeof(CC),1,fp2);
                else
                  found=1;
            }

        }
       }
    fclose(fp1);
    fclose(fp2);
    if(found==0)
    {
        remove("temp.bin");
    }
    else
    {
        result=remove("customer.bin");
        if(result!=0)
            return 2;
        result=rename("temp.bin","customer.bin");
        if(result!=0)
            return 2;
    }
    update_car_count(c_id);
    return found;
}
 void update_car_count(int c_id)
{
    FILE* fp=fopen("car.bin","rb+");
    if(fp==NULL)
    {
        printf("Sorry file cannot be open!");
        getch();
        return;
    }
    Car C;
    while(fread(&C,sizeof(Car),1,fp)==1)
    {
        if(C.car_id==c_id)
        {
            int x=C.car_count;
            x=x+1;
            fseek(fp,-8,SEEK_CUR);

            fwrite(&x,sizeof(x),1,fp);
            break;
        }
    }
    fclose(fp);
}


