#include <stdio.h>
#include <stdlib.h>
#include"conio2.h"
#include"car.h"

int main()
{
    User* usr;
    int choice;
    int i,k,counter=0,result,found,a;
    gotoxy(25,10);
    textcolor(LIGHTMAGENTA);
    printf("WELCOME TO CAR RENTAL SYSTEM");
    gotoxy(20,12);
    textcolor(YELLOW);
    printf("*RENT A CAR AND GO WHEREVER YOU WANT*");
    getch();
    addAdmin();
    while(1)
    {
        clrscr();
        gotoxy(32,2);
        textcolor(LIGHTGRAY);
        printf("CAR RENTAL SYSTEM");
        gotoxy(1,10);
        textcolor(YELLOW);
        for(i=0;i<80;i++)
        printf("*");
        gotoxy(1,20);
        for(i=0;i<80;i++)
        printf("*");
        gotoxy(32,12);
        textcolor(LIGHTCYAN);
        printf("1. Admin");
        gotoxy(32,14);
        printf("2. Employee");
        gotoxy(32,16);
        printf("3. Quit");
        gotoxy(32,18);
        textcolor(WHITE);
        printf("Select your Role:");
        do
        {
        scanf("%d",&choice);
        switch(choice)
        {
        case 1:
            {
                do
                {
                    counter=counter+1;
                   usr=getInput();
                   if(usr==NULL)
                      break;
                   else
                    {
                        k=checkUserExist(*usr,"admin");
                    }
                }while(k==0 && counter!=5);
                if(k==-1)
                    break;
                if(k==1)
                {
                    gotoxy(32,22);
                    textcolor(WHITE);
                    printf("Press any key to continue");
                    getch();
                    while(1)
                    {
                        clrscr();
                        result=adminMenu();
                        if(result==7)
                        {
                            clrscr();
                            break;
                        }
                        switch(result)
                        {
                        case 1:
                                clrscr();
                               addEmployee();
                               break;
                        case 2:
                                clrscr();
                                addCarDetails();
                               break;
                        case 3:
                                  clrscr();
                                 viewEmployee();
                                 break;
                        case 4:
                                   clrscr();
                                  showCarDetails();
                                  break;
                        case 5:
                                    clrscr();
                                   found=deleteEmp();
                                   gotoxy(32,16);
                                   if(found==0)
                                   {
                                       textcolor(LIGHTRED);
                                       printf("SORRY! NO EMPLOYEE OF THE GIVEN ID FOUND!");
                                   }
                                   else if(found==1)
                                   {
                                       textcolor(LIGHTGREEN);
                                       printf("RECORD DELETED SUCCESSFULLY!");
                                   }
                                   else if(found==2)
                                   {
                                       textcolor(LIGHTRED);
                                       printf("ERROR IN DELETION!");
                                   }
                                   textcolor(WHITE);
                                   gotoxy(32,18);
                                   printf("PRESS ANY KEY TO GO BACK TO MAIN MENU!");
                                   getch();
                                   break;
                        case 6:
                                    clrscr();
                                   found=deleteCarModel();
                                   gotoxy(32,16);
                                   if(found==0)
                                   {
                                       textcolor(LIGHTRED);
                                       printf("SORRY! NO CAR OF THE GIVEN ID FOUND!");
                                   }
                                   else if(found==1)
                                   {
                                       textcolor(LIGHTGREEN);
                                       printf("RECORD DELETED SUCCESSFULLY!");
                                   }
                                   else if(found==2)
                                   {
                                       textcolor(LIGHTRED);
                                       printf("ERROR IN DELETION!");
                                   }
                                   textcolor(WHITE);
                                   gotoxy(32,18);
                                   printf("PRESS ANY KEY TO GO BACK TO MAIN MENU!");
                                   getch();
                                   break;
                        default:
                                 gotoxy(32,22);
                                 textcolor(LIGHTRED);
                                 printf("Invalid choice. Try again!");
                                 getch();
                                 gotoxy(32,22);
                                 printf("\t\t\t\t");
                        }
                    }
                }
                if(counter==5)
                {
                gotoxy(32,23);
                textcolor(LIGHTRED);
                printf("Login limit exceeded. Try Later!");
                getch();
                gotoxy(32,22);
                printf("\t\t\t\t");
                }
            }
        case 2:
            {

                do
                {
                    counter=counter+1;
                   usr=getInput();
                   if(usr==NULL)
                      break;
                   else
                    {
                        k=checkUserExist(*usr,"emp");
                    }
                }while(k==0&&counter!=5);
                if(k==-1)
                    break;
                if(k==1)
                {
                    gotoxy(32,22);
                    textcolor(WHITE);
                    printf("Press any key to continue");
                    getch();
                    while(1)
                    {
                        clrscr();
                        result=EmpMenu();
                        if(result==6)
                        {
                            clrscr();
                            break;
                        }
                        switch(result)
                        {
                        case 1:
                                clrscr();
                                a=RentCar();
                                if(a==-2)
                                {
                                    gotoxy(32,22);
                                    textcolor(LIGHTRED);
                                    printf("Sorry! All Cars are Booked! Try Later.");
                                    getch();
                                }
                                else if(a==0)
                                {
                                    gotoxy(32,22);
                                    textcolor(LIGHTRED);
                                    printf("You did not choose any Car!");
                                    getch();
                                }
                               break;
                        case 2:
                                clrscr();
                                 BookedCarDetails();
                               break;
                        case 3:
                                  clrscr();
                                   AvailCarDetails();
                                  break;
                        case 4:
                                   clrscr();
                                   showCarDetails();
                                   break;
                        case 5:
                                   clrscr();
                                   result=returnCar();
                                    gotoxy(15,14);
                                   if(result==0)
                                  {
                                    gotoxy(32,15);
                                    textcolor(LIGHTRED);
                                    printf("Sorry! No record of the given car found");
                                    getch();
                                  }
                                  else if(result==1)
                                  {
                                   gotoxy(32,15);
                                   textcolor(LIGHTGREEN);
                                   printf("Car returned successfully!");
                                   getch();
                                   break;
                                  }
                                 else if(result==2)
                                 {
                                    textcolor(LIGHTRED);
                                    gotoxy(32,16);
                                    textcolor(WHITE);
                                    printf("Press any key to return back");
                                    getch();
                                    break;
                                 }
                        default:
                                 gotoxy(32,22);
                                 textcolor(LIGHTRED);
                                 printf("Invalid choice. Try again!");
                                 getch();
                                 gotoxy(32,22);
                                 printf("\t\t\t\t\t\t");
                        }
                    }

                }
                if(counter==5)
                {
                gotoxy(32,23);
                textcolor(LIGHTRED);
                printf("Login limit exceeded. Try Later!");
                getch();
                gotoxy(32,22);
                printf("\t\t\t\t");
                }
            }
        case 3:
            {
                clrscr();
                gotoxy(30,15);
                textcolor(LIGHTGREEN);
                printf("Thankyou for using the app");
                getch();
                exit(0);
            }
        default:
            gotoxy(32,22);
            textcolor(LIGHTRED);
            printf("Invalid choice. Try again!");
            getch();
            gotoxy(32,22);
            printf("\t\t\t\t\t");
            gotoxy(49,18);
            printf("\t\t\t");
            gotoxy(49,18);
            textcolor(WHITE);
        }
        }while(1);
        getch();
    }
    return 0;
}
